$(function () {
  $(".match-height-bootstrap-row > * > *").matchHeight();
  $(".match-height > *").matchHeight();
});
