<section class="companies-partnered-with-us-wrapper">
        <div class="container">
          <div class="row">
            <div class="col-xs-12">
              <div class="companies-partnered-with-us">
                <p class="text-30">Companies partnered with us</p>
                <div class="row row-13">
                  <div class="col-md-9 col-xs-12">
                    <div class="col-data-wrapper-5 clearfix">
                      <img class="layer-20" src="<?php echo get_template_directory_uri(); ?>/images/layer_20.png" alt="">
                      <img class="facebook-logo-meaning" src="<?php echo get_template_directory_uri(); ?>/images/facebook-logo-meaning.png" alt="">
                      <img class="layer-22" src="<?php echo get_template_directory_uri(); ?>/images/layer_22.png" alt="">
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-6 col-xs-12 clearfix">
                    <img class="layer-23" src="<?php echo get_template_directory_uri(); ?>/images/layer_23.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
</section>