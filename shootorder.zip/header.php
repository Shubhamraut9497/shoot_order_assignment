<!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <title>shootorder</title>
    <meta charset="UTF-8">
    <meta name="description" content="Digital Marketing">
    <meta name="keywords" content="Digital Marketing company">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <?php wp_head(); ?>
    
  </head>
 